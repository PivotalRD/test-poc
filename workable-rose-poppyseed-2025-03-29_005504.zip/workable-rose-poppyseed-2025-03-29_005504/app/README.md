# Flying-Bird-Vanilla-JS
 
   Classical Flying-Bird game with plane-JavaScript(no canvas).
 
 # Game-play & Controls
   
   Use arrow keys and space bar for bird movements.
   
 # Play here 
    
   <a href = "https://manoharys.github.io/Flying-Bird-Vanilla-JS/"> CLICK HERE </a>
  
# Preview
 
  <img src = 'https://github.com/manoharys/Flying-Bird-Vanilla-JS/blob/master/preview.gif'>
